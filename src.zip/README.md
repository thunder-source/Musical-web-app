# Restaurant Website

A clean, beautiful and responsive Music Web App.

## Demo

[![](src/assets/logo.png)](https://musical-webapp.netlify.app/)

## Features

- Search, play, pause, forward, backward, shuffle songs
- Loop songs, Around You Songs, Responsive Design and sort by Musical genres.
- Complete Responsive
- Smooth navigation

## 🚀 About Me

I'm a Praditya works in Reprar as a Frontend developer. i usually works in react and react-native.

## 🛠 Skills

Javascript, HTML, CSS, Bootstrap, React, Redux, Rapid API, Expo, React native, Java and Data Structures and Algorithms

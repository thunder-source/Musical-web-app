import loader from "./loader.svg";
import logo from "./logo.png";

export { logo, loader };
